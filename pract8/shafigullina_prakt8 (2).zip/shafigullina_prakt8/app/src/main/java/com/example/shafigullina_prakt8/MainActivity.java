package com.example.shafigullina_prakt8;

import static android.os.Build.VERSION_CODES.S;

import static java.lang.Math.*;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void startNewActivity(View v) {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }


    public void calculatePerimeter(View v) {
        EditText inputFieldR1 = findViewById(R.id.inputFieldR1);
        EditText inputFieldR2 = findViewById(R.id.inputFieldR2);

        TextView resultField = findViewById(R.id.resultField);


        String inputR1 = inputFieldR1.getText().toString();
        String inputR2 = inputFieldR2.getText().toString();




        double R1 = Double.parseDouble(inputR1);
        double R2 = Double.parseDouble(inputR2);


        double S1 =  (Math.PI * R1 * R1);
        double S2 =  (Math.PI * R2 * R2);
        double S3 = S1 - S2;


        resultField.setText(String.format("S1 = %.2f\nS2 = %.2f\nS3=%.2f", S1, S2,S3));
    }
}
