package com.example.shafigullina_prakt8;

import static java.lang.Math.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }

    public void calculateCircleProperties(View v) {

        EditText inputFieldX = findViewById(R.id.inputFieldX);

        String inputX = inputFieldX.getText().toString();



        double x = Double.parseDouble(inputX);
        double y=(4 * Math.pow((x - 3), 6) - 7 * Math.pow((x - 3), 6) + 2);



        TextView resultField = findViewById(R.id.resultField);
        resultField.setText(String.format("y = %.2f", y));



    }

    public void startNewActivity(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
